package fahrialamsyah.jfood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JfoodApplicationTests {

	@Test
	void contextLoads() {
	}

}
